import os
import pandas as pd

def extract_values(folder_path, output_csv):
    # Build file paths dynamically
    sterimol_file = os.path.join(folder_path, "Sterimol_results.txt")
    cone_angle_file = os.path.join(folder_path, "Cone_angles_results.txt")

    # Step 1: Extract data from Sterimol_results.txt
    try:
        with open(sterimol_file, 'r') as file:
            lines = file.readlines()
            l_value = None
            b1_value = None
            b5_value = None
            for line in lines:
                if line.startswith("L Value:"):
                    l_value = float(line.split(":")[1].strip())
                elif line.startswith("B1 Value:"):
                    b1_value = float(line.split(":")[1].strip())
                elif line.startswith("B5 Value:"):
                    b5_value = float(line.split(":")[1].strip())
    except Exception as e:
        print(f"Error reading Sterimol file: {e}")
        l_value, b1_value, b5_value = None, None, None

    # Debug information
    #print("Extracted values from Sterimol_results.txt:")
    #print("L Value:", l_value)
    #print("B1 Value:", b1_value)
    #print("B5 Value:", b5_value)

    # Step 2: Extract data from Cone_angles_results.txt
    try:
        with open(cone_angle_file, 'r') as file:
            lines = file.readlines()
            cone_angle = None
            for line in lines:
                if line.startswith("Cone Angle:"):
                    cone_angle = float(line.split(":")[1].strip())
    except Exception as e:
        print(f"Error reading Cone angles file: {e}")
        cone_angle = None

    # Debug information
    #print("Extracted values from Cone_angles_results.txt:")
    #print("Cone Angle:", cone_angle)

    # Step 3: Get the folder name for the first column
    folder_name = os.path.basename(folder_path)  # Get the folder name

    # Step 4: Create a DataFrame and save it as CSV
    data = {
        "Folder_Name": [folder_name],  # Use folder name instead of file name
        "L Value": [l_value],
        "B1 Value": [b1_value],
        "B5 Value": [b5_value],
        "Cone Angle": [cone_angle]
    }

    df = pd.DataFrame(data)
    df.to_csv(output_csv, index=False)
    print(f"Converted file saved to: {output_csv}")

# Input folder path (replace this with the actual folder path containing the files)
folder_path = os.getcwd()  # Current working directory
output_csv = os.path.join(folder_path, "Sterimol_AND_cone-results.csv")  # Output CSV file

# Call the function
extract_values(folder_path, output_csv)
