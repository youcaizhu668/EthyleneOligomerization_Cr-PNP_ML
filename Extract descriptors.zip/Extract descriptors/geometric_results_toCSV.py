import os
import pandas as pd

def extract_data_with_titles(geometry_file, output_csv):
    # Define the row titles
    dihedral_titles = ["Dihedral_" + "_".join(map(str, dihedral)) for dihedral in [
        [1, 4, 2, "R3"], [1, 2, 4, "R4"], [1, 3, 2, "R2"], [1, 3, 4, "R5"], [1, 2, 3, "R1"], [1, 2, 4, 3]
    ]]

    angle_titles = ["Angle_" + "_".join(map(str, angle)) for angle in [
        [1, 2, 4], [2, 1, 3], [4, 1, 3], [3, 2, 4], [3, 2, 17], [3, 4, 17],
        [4, "R5", 1], [4, "R5", 3], [4, "R5", "R4"], [4, "R4", 1], [4, "R4", 3],
        [2, "R3", 1], [2, "R3", 3], [2, "R3", "R2"], [2, "R2", 1], [2, "R2", 3], [3, 1, 17]
    ]]

    distance_titles = ["Distance_" + "_".join(map(str, distance)) for distance in [
        [1, 2], [1, 4], [1, 3], [2, 3], [2, 4], [3, 4], [3, "R1"], [4, "R4"],
        [4, "R5"], [3, "R1"], [2, "R3"], [2, "R2"], [1, "R2"], [1, "R3"],
        [1, "R4"], [1, "R5"], ["R2", "R3"], ["R4", "R5"]
    ]]

    all_titles = ["Folder_Name"] + dihedral_titles + angle_titles + distance_titles

    # Extract folder name from file path
    folder_name = os.path.basename(os.path.dirname(os.path.abspath(geometry_file)))

    # Initialize the result with folder name
    results = [folder_name]

    # Read the geometric results file
    with open(geometry_file, 'r') as file:
        lines = file.readlines()

    for line in lines:
        line = line.strip()
        if line.startswith("Dihedral angle for atoms") or line.startswith("Angle for atoms") or line.startswith("Distance between atoms"):
            # Extract the second-to-last value
            parts = line.split()
            value = float(parts[-2])  # Second-to-last value is the numeric data
            results.append(value)

    # Check if results match the number of titles (excluding folder name)
    if len(results) != len(all_titles):
        raise ValueError("Number of extracted values does not match the number of titles. Check the input file structure.")

    # Create a DataFrame
    df = pd.DataFrame([results], columns=all_titles)

    # Save to CSV
    df.to_csv(output_csv, index=False)
    print(f"Converted file saved to: {output_csv}")


# File paths
geometry_file = "Geometric_results.txt"  # Replace with your actual file path
output_csv = "Geometric_results.csv"  # Replace with your desired output file path

# Run the function
extract_data_with_titles(geometry_file, output_csv)
