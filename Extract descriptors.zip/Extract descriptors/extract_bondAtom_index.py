import csv
import re
import os

def calculate_binding_indices(row, core_atom_count=4):
    """
    Calculate the atomic indices for R1, R2, R3, R4, R5 groups connected to core atoms (Cr, P1, N, P2).
    """
    atom_pattern = r'\[[^\]]+\]|[A-GI-Za-z]'
    r1 = row.get("R1", "").strip()
    r2 = row.get("R2", "").strip()
    r3 = row.get("R3", "").strip()
    r4 = row.get("R4", "").strip()
    r5 = row.get("R5", "").strip()
    r1_atoms = len(re.findall(atom_pattern, r1))
    r2_atoms = len(re.findall(atom_pattern, r2))
    r3_atoms = len(re.findall(atom_pattern, r3))
    r4_atoms = len(re.findall(atom_pattern, r4))
    r5_atoms = len(re.findall(atom_pattern, r5))
    if r1 == "H":
        r1_index = 29
        r2_index = core_atom_count + 1
        r3_index = core_atom_count + r2_atoms + 1
        r4_index = core_atom_count + r2_atoms + r3_atoms + 1
        r5_index = core_atom_count + r2_atoms + r3_atoms + r4_atoms + 1
        return r1_index, r2_index, r3_index, r4_index, r5_index
    else:
        r2_index = core_atom_count + 1
        r3_index = core_atom_count + r2_atoms + 1
        r1_index = core_atom_count + r2_atoms + r3_atoms + 1
        r4_index = core_atom_count + r2_atoms + r3_atoms + r1_atoms + 1
        r5_index = core_atom_count + r2_atoms + r3_atoms + r1_atoms + r4_atoms + 1
        return r1_index, r2_index, r3_index, r4_index, r5_index

def save_to_txt(molname, indices):
    """
    Save the indices for a molecule to a TXT file.
    """
    filename = f"{molname}_bondAtom_index.txt"
    with open(filename, "w") as file:
        file.write(f"R1_index: {indices[0]}\n")
        file.write(f"R2_index: {indices[1]}\n")
        file.write(f"R3_index: {indices[2]}\n")
        file.write(f"R4_index: {indices[3]}\n")
        file.write(f"R5_index: {indices[4]}\n")
    return filename

def main(input_file):
    """
    Read the input CSV file and calculate binding atom indices for each molecule, only for the current directory's folder.
    """
    current_folder = os.path.basename(os.getcwd())  # Get the current folder name
    try:
        # Read the CSV file
        with open(input_file, mode="r", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            for row in reader:
                molname = row.get("molname", "Unknown")
                # Only generate the index file if the molecule's name matches the current folder name
                if molname == current_folder:
                    try:
                        # Calculate the binding atom indices
                        r1_index, r2_index, r3_index, r4_index, r5_index = calculate_binding_indices(row)
                        filename = save_to_txt(molname, (r1_index, r2_index, r3_index, r4_index, r5_index))
                        print(f"Saved {filename}")
                    except Exception as e:
                        print(f"{molname:<10} Error: {e}")
    except FileNotFoundError:
        print(f"Error: File {input_file} not found.")
    except Exception as e:
        print(f"Error processing file: {e}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python extract_binding_indices.py <input_csv_file>")
    else:
        input_file = sys.argv[1]
        main(input_file)
