import os
import shutil
import re
from pathlib import Path

def organize_log_files():
    current_dir = Path.cwd()
    log_files = list(current_dir.glob("*.log"))

    # Just keep L_comformer_number.log file
    pattern = re.compile(r"^(.*?_conformer_\d+)\.log$")

    for log_file in log_files:
        match = pattern.match(log_file.name)
        if not match:
            continue

        base_name = match.group(1)  # e.g., L1_conformer_1
        folder_name = current_dir / base_name
        folder_name.mkdir(exist_ok=True)

        # files to be moved
        related_files = [
            f"{base_name}.log",
            f"{base_name}_Ligand.log",
            f"{base_name}_NBO.log"
        ]

        for filename in related_files:
            source_path = current_dir / filename
            if source_path.exists():
                shutil.move(str(source_path), str(folder_name / filename))
                print(f"move: {filename} to {folder_name}")
            else:
                print(f"not found: {filename}")

if __name__ == "__main__":
    organize_log_files()
