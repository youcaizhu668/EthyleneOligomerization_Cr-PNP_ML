import os
from morfeus import ConeAngle, read_xyz

def calculate_cone_angles_in_directory(directory, output_file="Cone_angles_results.txt"):
    """
    Calculate cone angles for all .xyz files ending with 'NoP.xyz' in the specified directory.

    Parameters:
    - directory: The directory containing .xyz files ending with 'NoP.xyz'.
    - output_file: The name of the TXT file to save results.

    Outputs:
    - A TXT file with cone angle results for each .xyz file.
    """
    # Prepare the output list
    results = []

    # Iterate through all files in the directory
    for filename in os.listdir(directory):
        if filename.endswith("NoP.xyz"):  # Process only files ending with 'NoP.xyz'
            filepath = os.path.join(directory, filename)
            try:
                # Read the XYZ file
                elements, coordinates = read_xyz(filepath)

                # Assume the central atom is the first atom (index 1)
                cone_angle = ConeAngle(elements, coordinates, 1)

                # Extract cone angle and tangent atoms
                angle = cone_angle.cone_angle
                tangent_atoms = cone_angle.tangent_atoms

                # Print results to the console
                print(f"File: {filename}")
                print(f"Cone Angle: {angle:.2f}")
                print(f"Tangent Atoms: {tangent_atoms}")

                # Save results to the list
                results.append({
                    "Filename": filename,
                    "Cone Angle": round(angle, 2),
                    "Tangent Atoms": ",".join(map(str, tangent_atoms))
                })

            except Exception as e:
                print(f"Error processing file {filename}: {e}")

    # Write results to the output TXT file
    with open(output_file, "w") as outfile:
        outfile.write("Cone Angle Results\n")
        outfile.write("=" * 50 + "\n")
        for result in results:
            outfile.write(f"Filename: {result['Filename']}\n")
            outfile.write(f"Cone Angle: {result['Cone Angle']}\n")
            outfile.write(f"Tangent Atoms: {result['Tangent Atoms']}\n")
            outfile.write("-" * 50 + "\n")

    print(f"Results saved to {output_file}")


if __name__ == "__main__":
    # Set the current directory as the working directory
    current_directory = os.getcwd()

    # Run the cone angle calculation for all .xyz files ending with 'NoP.xyz' in the directory
    calculate_cone_angles_in_directory(current_directory)
