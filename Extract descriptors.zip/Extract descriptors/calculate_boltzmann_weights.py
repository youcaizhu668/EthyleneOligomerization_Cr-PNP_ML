# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import os

try:
    # Current working directory
    current_dir = os.getcwd()

    # Input file name
    input_file = os.path.join(current_dir, "Gibbs_final.csv")

    # Output file name based on current folder name
    folder_name = os.path.basename(current_dir)
    output_file = os.path.join(current_dir, f"{folder_name}_boltzmann_weights.txt")

    # Read CSV with no header
    df = pd.read_csv(input_file, header=None)

    # Use the last column as Gibbs free energy (��G)
    dg_values = df.iloc[:, -1]

    # Constants
    R = 0.001987  # kcal/(mol��K)
    T = 298.15

    # Calculate relative energies
    min_energy = dg_values.min()
    relative_energies = dg_values - min_energy

    # Calculate Boltzmann weights
    boltz_factors = np.exp(-relative_energies / (R * T))
    boltzmann_weights = boltz_factors / boltz_factors.sum()

    # Get conformer names from first column
    conformer_names = df.iloc[:, 0]

    # Write results to the text file
    with open(output_file, "w") as f:
        f.write("Conformer Boltzmann weights:\n")
        for name, energy, weight in zip(conformer_names, relative_energies, boltzmann_weights):
            f.write(f"{name}: Energy = {energy:.4f} kcal/mol, Boltzmann weight = {weight:.4f}\n")

    print(f"Boltzmann weights saved to: {output_file}")

except Exception as e:
    print(f"Error while calculating Boltzmann weights: {e}")
