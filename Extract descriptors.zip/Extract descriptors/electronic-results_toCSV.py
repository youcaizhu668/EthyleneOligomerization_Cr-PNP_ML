import os
import csv
import pandas as pd

# Keys to exclude from NBO and Ligand input files
exclude_keys_nbo = {
    "Catalyst_P1_LP_occ", "Catalyst_P1_LP_eng",
    "Catalyst_P3_LP_occ", "Catalyst_P3_LP_eng",
    "Filename"
}
exclude_keys_ligand = {
    "Ligand_Beta_HOMO", "Ligand_Beta_LUMO",
    "Filename"
}

# Function to parse input txt file and exclude unwanted keys
def parse_result_file(filepath, exclude_keys):
    data = {}
    with open(filepath, "r") as file:
        for line in file:
            if ":" not in line:
                continue
            key, value = line.strip().split(":", 1)
            key = key.strip()
            value = value.strip()
            if key in exclude_keys:
                continue
            data[key] = value
    return data

# Function to generate combined CSV file
def generate_combined_csv(nbo_file, ligand_file, output_csv):
    try:
        # Parse data from both files
        nbo_data = parse_result_file(nbo_file, exclude_keys_nbo)
        ligand_data = parse_result_file(ligand_file, exclude_keys_ligand)

        # Combine keys and values
        all_keys = list(nbo_data.keys()) + list(ligand_data.keys())
        all_values = list(nbo_data.values()) + list(ligand_data.values())

        # Use current folder name as identifier
        folder_name = os.path.basename(os.getcwd())

        # Write to CSV
        with open(output_csv, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Folder_Name"] + all_keys)
            writer.writerow([folder_name] + all_values)

        print("CSV file generated successfully.")
    except Exception as e:
        print(f"Failed to generate CSV: {e}")

# File paths
nbo_txt = "Electronic-results_NBO.txt"
ligand_txt = "Electronic-results_Ligand.txt"
output_csv = "Electronic-results.csv"

# Run main function
generate_combined_csv(nbo_txt, ligand_txt, output_csv)
