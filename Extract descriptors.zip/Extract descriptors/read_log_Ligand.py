import os
import re
from pathlib import Path

def get_bond_atom_indices():
    parent = Path("..")
    file = list(parent.glob("*_bondAtom_index.txt"))
    if not file:
        print("not found *_bondAtom_index.txt file")
        return {}

    index_dict = {}
    with open(file[0], "r", encoding="utf-8") as f:
        for line in f:
            match = re.match(r"(R\d+)_index:\s*(\d+)", line.strip())
            if match:
                label = match.group(1)
                idx = int(match.group(2)) - 1
                index_dict[label] = idx
    return index_dict

def extract_gaussian_info(filepath, extra_nbo_indices):
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()

    state_index = max(
        (idx for idx, line in enumerate(lines) if "The electronic state is" in line),
        default=0
    )
    relevant_lines = lines[state_index:]

    alpha_occ_values, alpha_virt_values = [], []
    beta_occ_values, beta_virt_values = [], []

    for line in relevant_lines:
        if "Alpha  occ. eigenvalues" in line:
            alpha_occ_values.extend(line.strip().split("--")[-1].split())
        if "Alpha virt. eigenvalues" in line:
            alpha_virt_values.extend(line.strip().split("--")[-1].split())
        if "Beta  occ. eigenvalues" in line:
            beta_occ_values.extend(line.strip().split("--")[-1].split())
        if "Beta virt. eigenvalues" in line:
            beta_virt_values.extend(line.strip().split("--")[-1].split())

    alpha_occ_last = alpha_occ_values[-1] if alpha_occ_values else "NA"
    alpha_virt_first = alpha_virt_values[0] if alpha_virt_values else "NA"
    beta_occ_last = beta_occ_values[-1] if beta_occ_values else "NA"
    beta_virt_first = beta_virt_values[0] if beta_virt_values else "NA"

    nbo_section = []
    for i, line in enumerate(lines):
        if "Summary of Natural Population Analysis" in line:
            for j in range(i + 1, i + 100):
                if j >= len(lines):
                    break
                l = lines[j].strip()
                if not l or "----" in l or "Atom" in l or "Charge" in l:
                    continue
                tokens = l.split()
                if len(tokens) >= 3 and tokens[1].isdigit():
                    nbo_section.append(tokens)
            break

    base_atom_charges = {}
    for atom_id in range(1, 6):
        charge = "NA"
        for tokens in nbo_section:
            try:
                if int(tokens[1]) == atom_id:
                    charge = tokens[2]
                    break
            except:
                continue
        base_atom_charges[f"Ligand_NBO_Charge_{atom_id}"] = charge

    bondatom_charges = {}
    for label, atom_idx in extra_nbo_indices.items():
        charge = "NA"
        for tokens in nbo_section:
            try:
                if int(tokens[1]) == atom_idx:
                    charge = tokens[2]
                    break
            except:
                continue
        bondatom_charges[f"Ligand_NBO_Charge_{label}"] = charge

    # LP
    P1_LP_occ, P1_LP_eng = 'NA', 'NA'
    N2_LP_occ, N2_LP_eng = 'NA', 'NA'
    P3_LP_occ, P3_LP_eng = 'NA', 'NA'
    pattern_P1 = r"LP\s+\(\s*1\s*\)\s+P\s+1\s+"
    pattern_N2 = r"LP\s+\(\s*1\s*\)\s+N\s+2\s+"
    pattern_P3 = r"LP\s+\(\s*1\s*\)\s+P\s+3\s+"

    for line in reversed(lines):
        if re.search(pattern_P1, line):
            tokens = line.split()
            if len(tokens) >= 8:
                P1_LP_occ = tokens[6]
                P1_LP_eng = tokens[7]
            break

    for line in reversed(lines):
        if re.search(pattern_N2, line):
            tokens = line.split()
            if len(tokens) >= 8:
                N2_LP_occ = tokens[6]
                N2_LP_eng = tokens[7]
            break

    for line in reversed(lines):
        if re.search(pattern_P3, line):
            tokens = line.split()
            if len(tokens) >= 8:
                P3_LP_occ = tokens[6]
                P3_LP_eng = tokens[7]
            break

    BD_occ_1_2, BD_eng_1_2 = "NA", "NA"
    BDstar_occ_1_2, BDstar_eng_1_2 = "NA", "NA"
    float_pattern = r"[-+]?\d*\.\d+(?:[eE][-+]?\d+)?"
    pattern_bd_1_2 = r"BD\s*\(\s*1\s*\)\s+\w+\s+1\s*-\s*\w+\s+2\s|BD\s*\(\s*1\s*\)\s+\w+\s+2\s*-\s*\w+\s+1\s"
    pattern_bdstar_1_2 = r"BD\*\s*\(\s*1\s*\)\s+\w+\s+1\s*-\s*\w+\s+2\s|BD\*\s*\(\s*1\s*\)\s+\w+\s+2\s*-\s*\w+\s+1\s"
    BD_occ_2_3, BD_eng_2_3 = "NA", "NA"
    BDstar_occ_2_3, BDstar_eng_2_3 = "NA", "NA"
    pattern_bd_2_3 = r"BD\s*\(\s*1\s*\)\s+\w+\s+2\s*-\s*\w+\s+3\s|BD\s*\(\s*1\s*\)\s+\w+\s+3\s*-\s*\w+\s+2\s"
    pattern_bdstar_2_3 = r"BD\*\s*\(\s*1\s*\)\s+\w+\s+2\s*-\s*\w+\s+3\s|BD\*\s*\(\s*1\s*\)\s+\w+\s+3\s*-\s*\w+\s+2\s"

    for line in reversed(lines):
        if re.search(pattern_bd_1_2, line):
            floats = re.findall(float_pattern, line)
            if len(floats) >= 2:
                BD_occ_1_2 = floats[0]
                BD_eng_1_2 = floats[1]
            break

    for line in reversed(lines):
        if re.search(pattern_bdstar_1_2, line):
            floats = re.findall(float_pattern, line)
            if len(floats) >= 2:
                BDstar_occ_1_2 = floats[0]
                BDstar_eng_1_2 = floats[1]
            break
            
            
            
            
    for line in reversed(lines):
        if re.search(pattern_bd_2_3, line):
            floats = re.findall(float_pattern, line)
            if len(floats) >= 2:
                BD_occ_2_3 = floats[0]
                BD_eng_2_3 = floats[1]
            break

    for line in reversed(lines):
        if re.search(pattern_bdstar_2_3, line):
            floats = re.findall(float_pattern, line)
            if len(floats) >= 2:
                BDstar_occ_2_3 = floats[0]
                BDstar_eng_2_3 = floats[1]
            break             
          
    # BD between atom and Rn
    target_pairs = [
        ("R1", 2),
        ("R2", 3),
        ("R3", 3),
        ("R4", 1),
        ("R5", 1)
    ]

    for label, atom_a in target_pairs:
        atom_b = extra_nbo_indices.get(label)
        if atom_b is None:
            continue

        BD_occ_x, BD_eng_x = "NA", "NA"
        BDstar_occ_x, BDstar_eng_x = "NA", "NA"

        pattern_bd = rf"BD\s*\(\s*1\s*\)\s+\w+\s+{atom_a}\s*-\s*\w+\s+{atom_b}\s|BD\s*\(\s*1\s*\)\s+\w+\s+{atom_b}\s*-\s*\w+\s+{atom_a}\s"
        pattern_bdstar = rf"BD\*\s*\(\s*1\s*\)\s+\w+\s+{atom_a}\s*-\s*\w+\s+{atom_b}\s|BD\*\s*\(\s*1\s*\)\s+\w+\s+{atom_b}\s*-\s*\w+\s+{atom_a}\s"

        for line in reversed(lines):
            if re.search(pattern_bd, line):
                floats = re.findall(float_pattern, line)
                if len(floats) >= 2:
                    BD_occ_x = floats[0]
                    BD_eng_x = floats[1]
                break

        for line in reversed(lines):
            if re.search(pattern_bdstar, line):
                floats = re.findall(float_pattern, line)
                if len(floats) >= 2:
                    BDstar_occ_x = floats[0]
                    BDstar_eng_x = floats[1]
                break

        bondatom_charges[f"Ligand_BD_{atom_a}_{label}_occ"] = BD_occ_x
        bondatom_charges[f"Ligand_BD_{atom_a}_{label}_eng"] = BD_eng_x
        bondatom_charges[f"Ligand_BD*_{atom_a}_{label}_occ"] = BDstar_occ_x
        bondatom_charges[f"Ligand_BD*_{atom_a}_{label}_eng"] = BDstar_eng_x

    result = {
        "Filename": os.path.basename(filepath),
        "Ligand_Alpha_HOMO": alpha_occ_last,
        "Ligand_Alpha_LUMO": alpha_virt_first,
        "Ligand_Beta_HOMO": beta_occ_last,
        "Ligand_Beta_LUMO": beta_virt_first,
        "Ligand_P1_LP_occ": P1_LP_occ,
        "Ligand_P1_LP_eng": P1_LP_eng,
        "Ligand_N2_LP_occ": N2_LP_occ,
        "Ligand_N2_LP_eng": N2_LP_eng,
        "Ligand_P3_LP_occ": P3_LP_occ,
        "Ligand_P3_LP_eng": P3_LP_eng,
        "Ligand_BD_1_2_occ": BD_occ_1_2,
        "Ligand_BD_1_2_eng": BD_eng_1_2,
        "Ligand_BD*_1_2_occ": BDstar_occ_1_2,
        "Ligand_BD*_1_2_eng": BDstar_eng_1_2,
        "Ligand_BD_2_3_occ": BD_occ_2_3,
        "Ligand_BD_2_3_eng": BD_eng_2_3,
        "Ligand_BD*_2_3_occ": BDstar_occ_2_3,
        "Ligand_BD*_2_3_eng": BDstar_eng_2_3
    }
    result.update(base_atom_charges)
    result.update(bondatom_charges)
    return result

def main():
    bondatom_indices = get_bond_atom_indices()
    output_file = "Electronic-results_Ligand.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        for file in Path(".").glob("*_Ligand.log"):
            result = extract_gaussian_info(file, bondatom_indices)
            for key, value in result.items():
                f.write(f"{key}: {value}\n")
            f.write("\n")
    print(f"extraction completed, the results saved to {output_file}")

if __name__ == '__main__':
    main()
